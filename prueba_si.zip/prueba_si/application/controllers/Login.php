<?php
class Login extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->model('login_model');
  }

  function index(){
    $this->load->view('login_view');
  }

  function auth(){
    $email    = $this->input->post('email',TRUE);
    $password = md5($this->input->post('password',TRUE));
    $validatemail = $this->login_model->validate_mail($email);
    if($validatemail->num_rows() == 0){
        echo $this->session->set_flashdata('msg','Usuario no existe, por favor verifique');
    }
      $validate = $this->login_model->validate($email,$password);
      if($validate->num_rows() > 0){
          $this -> contar_error($email, 0);

        $data       = $validate->row_array();
        $id       = $data['id'];
        $name       = $data['nombre'];
        $email      = $data['email'];
        $level      = $data['tipo_usuario'];
        $intentos   = $data['intentos_login'];

        $sesdata = array(
            'id'  => $id,
            'username'  => $name,
            'email'     => $email,
            'level'     => $level,
            'intentos'  => $intentos,
            'logged_in' => TRUE
        );
		if($intentos <= 2){
			$this->session->set_userdata($sesdata);
			if($level === '1'){
				$this->session->set_flashdata('msg','Bienvenido');
				redirect('page');
			}elseif($level === '2'){
				redirect('page/');
			}else{
				redirect('page/author');
			}
		}else{
			$this->session->set_flashdata('msg','Usuario Bloqueado');
			redirect('login');
		}
    }else{
          $validate = $this->login_model->validate_mail($email);
          $data = $validate->row_array();
          $intentos = $data['intentos_login'];
          if($intentos > 2){
              $this->session->set_flashdata('msg','Supero el Numero Maximo de intentos de Login, el usuario esta bloqueado');
              redirect('login');
          }else{
              $intentos = $intentos + 1;
              $inserta = $this -> contar_error($email, $intentos);
              if($inserta == true){
                  $this->session->set_flashdata('msg','Datos incorrectos');
                  redirect('login');
              }
          }
    }
  }

  function logout(){
      $this->session->sess_destroy();
      redirect('login');
  }

  private function contar_error($email, $num)
    {
        $fechaActual 		= date('Y-m-d\Th:m:s');
        $login_model	    = $this->login_model;
        $insertData         = $login_model->insertarerror($email, $num, $fechaActual);
        return $insertData;
    }
}
