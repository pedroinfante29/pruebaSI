<?php
class Page extends CI_Controller{
    function __construct(){
        parent::__construct();
        if($this->session->userdata('logged_in') !== TRUE){
            redirect('login');
        }
    }

    function index(){
        if(($this->session->userdata('level')==='1') || ($this->session->userdata('level')==='2')){
            $this->load->view('base/head');
            $this->load->view('base/navbar');
            $this->load->view('base/main');
            $this->load->view('listaV.php');
            $this->load->view('base/footer');
            $this->load->view('base/js');
        }else{
            $this->load->view('denegado');
        }

    }

    function staff(){
        if(($this->session->userdata('level')==='1') || ($this->session->userdata('level')==='2')){
        //if($this->session->userdata('level')==='2'){

            $this->load->view('base/head');
            $this->load->view('base/navbar');
            $this->load->view('base/main');
            $this->load->view('notas.php');
            $this->load->view('base/js');
        }else{
            $this->load->view('denegado');
        }
    }

    function author(){
        if($this->session->userdata('level')==='3'){
            $this->load->view('base/head');
            $this->load->view('base/navbar');
            $this->load->view('base/main');
            $this->load->view('listaV.php');
            $this->load->view('base/footer');
            $this->load->view('base/js');
        }else{
            $this->load->view('denegado');
        }
    }

}
