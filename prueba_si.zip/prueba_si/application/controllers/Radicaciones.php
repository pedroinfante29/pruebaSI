<?php

class Radicaciones extends CI_Controller {
	private $request;
	private $misnoticias;
	public function __construct(){
		parent::__construct();
        if($this->session->userdata('logged_in') !== TRUE){
            redirect('login');
        }
		$this->load->model('radicacion_model');
		$this->request = json_decode(file_get_contents('php://input'));
	}
	public function index(){
        if($this->session->userdata('level')==='1'){
            $this->load->view('base/head');
            $this->load->view('base/navbar');
            $this->load->view('base/main');
            $this->load->view('listaV.php');
            $this->load->view('base/footer');
            $this->load->view('base/js');
        }else{
            $this->load->view('denegado');
        }
	}
	public function recuperar_radicaciones(){
		$radicaciones = $this->radicacion_model->listar();
		if(!is_null($radicaciones)){
			echo json_encode($radicaciones);
		} else {
			echo 'Error al listar las radicaciones.';
		}
	}
	public function crear_radicacion(){
		$insertData = $this->radicacion_model->insertar(
			array(
			'nombre_solicitante'	=> $this->request->nombre_solicitante,
			'asunto'				=> $this->request->asunto,
			'texto_solicitud'		=> $this->request->texto_solicitud,
			'id'					=> $this->session->userdata('id')
		));
		if(is_null($insertData)){
			echo 'Error al insertar la radicacion.';
		} else {
            $this->process($insertData);
        }
	}
	public function ver_radi($id){
		if($this->session->userdata('level')==='1'){
//			$data = array('enlaces'=>$this->radicacion_model->listarRad($id));
			$data = array(
				'datos' => $this->radicacion_model->listarRad($id)
			);
//			$data = json_encode($data);
			if(!is_null($data)){
				$this->load->view('base/head');
				$this->load->view('base/navbar');
				$this->load->view('base/main');
				$this->load->view('data_radicacion', $data);
				$this->load->view('base/footer');
				$this->load->view('base/js');
			} else {
				echo 'Error al listar la informaci¨®n.';
			}
		}
	}

	public function editar_radi(){
		if($this->session->userdata('level')==='1'){
			$post						= $this->input->post();
			$data = array(
				'id'					=> $post['id'],
				'nombre_solicitante'	=> $post['nombre_solicitante'],
				'asunto' 				=> $post['asunto'],
				'texto_solicitud'		=> $post['texto_solicitud'],
				'id_user'				=> $this->session->userdata('id')
			);
			$insertData = $this->radicacion_model->updateRad($data);
			if(is_null($insertData)){
				echo 'Error al insertar la radicacion.';
			} else {
				$this->load->view('base/head');
				$this->load->view('base/navbar');
				$this->load->view('base/main');
				$this->load->view('listaV.php');
				$this->load->view('base/footer');
				$this->load->view('base/js');
			}
		}
	}

}
