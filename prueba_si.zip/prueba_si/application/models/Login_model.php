<?php
class Login_model extends CI_Model{

  function validate($email,$password = null){
    $this->db->where('email',$email);
    $this->db->where('password',$password);
    $result = $this->db->get('pru_users',1);
    return $result;
  }

  function validate_mail($email){
        $this->db->where('email',$email);
        $result = $this->db->get('pru_users',1);
        return $result;
  }

  public function insertarerror($mail, $num, $fechaActual)
    {
        $this->db->trans_start();
        $this->db->trans_strict(false);
        $this->db
            ->set('intentos_login',$num)
            ->set('date_login',$fechaActual)
            ->where('email', $mail)
            ->update('pru_users');
        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            return false;
        }
        $this->db->trans_commit();
        return true;
    }
}
