<?php
class Radicacion_model extends CI_Model {
	public function __construct(){
		parent::__construct();
	}
	public function insertar($data){
        $this->db->insert('pru_radicaciones', array(
			'nombre_solicitante'    => $data['nombre_solicitante'],
			'asunto' 				=> $data['asunto'],
			'texto_solicitud'       => $data['texto_solicitud'],
			'fecha'   				=> date('Y-m-d H:i:s'),
			'id_user'   			=> $data['id']
		));

	}

	public function updateRad(array $data)
	{
		$this->db->trans_start();
		$this->db->trans_strict(false);
		$data = [
			'nombre_solicitante'    => $data['nombre_solicitante'],
			'asunto' 				=> $data['asunto'],
			'texto_solicitud'       => $data['texto_solicitud'],
			'fecha'   				=> date('Y-m-d H:i:s'),
			'id'   					=> $data['id'],
			'id_user'   			=> $data['id_user']
		];
		$this->db->set($data)->where('id', $data['id'])->update('pru_radicaciones');
		if ($this->db->trans_status() === false) {
			$this->db->trans_rollback();
			return false;
		}
		$this->db->trans_commit();
		return true;
	}

	public function listar(){
		return $this->db
			->select('r.id, r.nombre_solicitante, r.fecha, r.asunto, r.texto_solicitud, r.id_user, u.nombre')
			->from('pru_radicaciones r')
			->join('pru_users u', 'u.id = r.id_user')
			->order_by('r.fecha ASC')
			->get()
			->result();
	}
	public function listarRad($id){
		return $this->db
			->select('r.id, r.nombre_solicitante, r.fecha, r.asunto, r.texto_solicitud, r.id_user, u.nombre')
			->from('pru_radicaciones r')
			->join('pru_users u', 'u.id = r.id_user')
			->where('r.id', $id)
			->get()
			->result();
	}

}
