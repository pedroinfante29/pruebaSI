<script src="<?php echo base_url()."template/";?>plugins/jquery/jquery.min.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/jquery-ui/jquery-ui.min.js"></script>
<script>
	$.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url()."template/";?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/chart.js/Chart.min.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/sparklines/sparkline.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/jquery-knob/jquery.knob.min.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/summernote/summernote-bs4.min.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="<?php echo base_url()."template/";?>dist/js/adminlte.js"></script>
<script src="<?php echo base_url()."template/";?>dist/js/pages/dashboard.js"></script>

<script src="<?php echo base_url()."template/";?>plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url()."template/";?>plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<script src="<?php echo base_url()."template/";?>dist/js/adminlte.min.js"></script>
<script src="<?php echo base_url()."template/";?>dist/js/demo.js"></script>

<script src="<?php echo base_url()."template/";?>/plugins/ekko-lightbox/ekko-lightbox.min.js"></script>
<script src="<?php echo base_url()."template/";?>/plugins/filterizr/jquery.filterizr.min.js"></script>


<script>
	$(function () {
		$("#example1").DataTable();
		$('#example2').DataTable({
			"paging": true,
			"lengthChange": false,
			"searching": false,
			"ordering": true,
			"info": true,
			"autoWidth": false,
		});
	});
</script>
<!--<script type="text/javascript">-->
<!--	$(function() {-->
<!--		const Toast = Swal.mixin({-->
<!--			toast: true,-->
<!--			position: 'top-end',-->
<!--			showConfirmButton: false,-->
<!--			timer: 3000-->
<!--		});-->
<!---->
<!--		$('.swalDefaultSuccess').click(function() {-->
<!--			Toast.fire({-->
<!--				type: 'success',-->
<!--				title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'-->
<!--			})-->
<!--		});-->
<!--		$('.swalDefaultInfo').click(function() {-->
<!--			Toast.fire({-->
<!--				type: 'info',-->
<!--				title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'-->
<!--			})-->
<!--		});-->
<!--		$('.swalDefaultError').click(function() {-->
<!--			Toast.fire({-->
<!--				type: 'error',-->
<!--				title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'-->
<!--			})-->
<!--		});-->
<!--	});-->
<!---->
<!--</script>-->

<script>
	$(function () {
		$(document).on('click', '[data-toggle="lightbox"]', function(event) {
			event.preventDefault();
			$(this).ekkoLightbox({
				alwaysShowClose: true
			});
		});

		$('.filter-container').filterizr({gutterPixels: 3});
		$('.btn[data-filter]').on('click', function() {
			$('.btn[data-filter]').removeClass('active');
			$(this).addClass('active');
		});
	})
</script>
</body>
</html>

