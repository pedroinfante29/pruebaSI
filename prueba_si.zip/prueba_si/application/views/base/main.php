<aside class="main-sidebar sidebar-dark-primary elevation-4">
	<a href="#" class="brand-link">
		<img src="<?php echo base_url()."assets/img/";?>logo.jpg" alt="Prueba Logo" class="brand-image img-circle elevation-3"
			 style="opacity: .8">
		<span class="brand-text font-weight-light">prueba Pedro</span>
	</a>

	<div class="sidebar">
		<div class="user-panel mt-3 pb-3 mb-3 d-flex">
			<div class="info">
				<a href="#" class="d-block"><?php echo $this->session->userdata('username');?></a>
			</div>
		</div>
		<nav class="mt-2">
			<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
				<li class="nav-item has-treeview">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-home"></i>
						<p>
							Inicio
							<i class="right fas fa-angle-left"></i>
						</p>
					</a>
					<ul class="nav nav-treeview">
						<li class="nav-item">
							<a href="<?php echo site_url('login/logout');?>" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Salir</p>
							</a>
						</li>
					</ul>
				</li>
				<li class="nav-item has-treeview">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-file"></i>
						<p>Radicaciones<i class="fas fa-angle-left right"></i></p>
					</a>
					<ul class="nav nav-treeview">
                        <?php if($this->session->userdata('level')==='1'):?>
                            <li class="nav-item">
                                <a href="<?php echo base_url()."index.php/page";?>" class="nav-link">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Consultar Radicaciones</p>
                                </a>
                            </li>
                        <?php else:?>
                            <li class="nav-item">
                                <a href="<?php echo base_url()."index.php/page/author";?>" class="nav-link">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Lista</p>
                                </a>
                            </li>
                        <?php endif;?>
					</ul>
				</li>
			</ul>
		</nav>
	</div>
</aside>
