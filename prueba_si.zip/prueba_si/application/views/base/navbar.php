
<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
	<!-- SEARCH FORM -->
	<form class="form-inline ml-3">
		<div class="input-group input-group-sm">
			<input type="text" id="myInput" onkeyup="myFunction()" class="form-control form-control-navbar" placeholder="Buscar" aria-label="Search">
			<div class="input-group-append">
				<button class="btn btn-navbar" type="button">
					<i class="fas fa-search"></i>
				</button>
			</div>
		</div>
	</form>
</nav>
<!-- /.navbar -->
