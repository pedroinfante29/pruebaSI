<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="wrapper">

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Lista de Radicaciones...</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                            <li class="breadcrumb-item active">Lista de Radicaciones</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <section class="content">
            <div class="row">
                <div class="col-12">
                    <div class="card-body">
                        <div action="javascript:void(0);" id="controlador_radicaciones">
							<div class="row">
								<div class="col-12">
									<form method="post" action="<?php echo base_url()."index.php/radicaciones/editar_radi/";?>">
                            <?php
                            if ( $this->session->userdata('level') == '1'){
								if(isset($datos)){
									foreach ($datos as $row){
										echo "
								
                                        <div class='input-group input-group-sm' >
                                            <input value='".$row->nombre_solicitante."' name='nombre_solicitante' class='form-control col-8' placeholder='Nombre' autocomplete='off' required>
                                        </div><br>
										<div class='input-group input-group-sm' >
                                            <input value='".$row->asunto."' name='asunto' class='form-control col-8' placeholder='Asunto' autocomplete='off' required>
                                        </div><br>
										<div class='input-group input-group-sm' >
                                            <input value='".$row->texto_solicitud."' name='texto_solicitud' class='form-control col-8' placeholder='Detalle' autocomplete='off' required>
                                        </div><br>
                                            <input value='".$row->id."' type='hidden' name='id' class='form-control col-8' placeholder='Detalle' autocomplete='off' required><br>
                                        <div class='input-group input-group-sm' >
                                            <span class='input-group-append'>
												<button type='submit' class='btn btn-success btn-flat' >Crear Radicación</button>
											</span>
                                        </div>


                                ";
									}
								}

                            }
                            ?>
									</form>
								</div>
							</div>
                            <hr>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>
</div>
</div>
<script>
	$(document).ready(function() {
		$('#example').DataTable();
	} );
</script>
<script type="text/javascript" src="<?php echo base_url() ?>js/appV.js"></script>
