<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>musicApp</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
        <style>
            body{
                background-image: url("https://appdesarrollo.co/musicapp/images/fondo.png");
                background-color: #cccccc;
                height: 500px;
                background-position: center;
                background-repeat: no-repeat;
                background-size: cover;
                position: relative;
            }
        </style>
    </head>
    <body>
    </body>
</html>