<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<script>
	<?php if($this->session->flashdata('msg')){ ?>
	Swal.fire({
		icon: 'success',
		title: 'Bienvenido',
		text: 'Al sistema de prueba de Pedro Infante',
	})
	<?php } ?>
</script>
<div class="wrapper">
	<link href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Lista de Radicaciones...</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                            <li class="breadcrumb-item active">Lista de Radicaciones</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <section class="content">
            <div class="row">
                <div class="col-12">
                    <div class="card-body">
                        <div action="javascript:void(0);" id="controlador_radicaciones">
                            <div v-if="cargando_radicaciones">
                                Cargando lista de Radicaciones...
                            </div>
                            <?php
                            if ( $this->session->userdata('level') == '1'){

                                ?>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="input-group input-group-sm" >
                                            <input v-model="radicacion_nueva.nombre_solicitante" class="form-control col-8" placeholder="Nombre" autocomplete="off" required>
                                        </div><br>
										<div class="input-group input-group-sm" >
                                            <input v-model="radicacion_nueva.asunto" class="form-control col-8" placeholder="Asunto"  autocomplete="off" required>
                                        </div><br>
										<div class="input-group input-group-sm" >
                                            <input v-model="radicacion_nueva.texto_solicitud" class="form-control col-8" placeholder="Detalle"  autocomplete="off" required>
                                        </div><br>
                                        <div class="input-group input-group-sm" >
                                            <span class="input-group-append">
												<button type="button" class="btn btn-success btn-flat" v-on:click="crearRadicacion()">Crear Radicación</button>
											</span>
                                        </div>
                                    </div>
                                </div>
                                <?php

                            }
                            ?>
                            <hr>
                            <script>
                                function myFunction() {
                                    var input, filter, tbody, tr, a, i, txtValue;
                                    input = document.getElementById("myInput");
                                    filter = input.value.toUpperCase();
                                    tbody = document.getElementById("myUL");
                                    tr = tbody.getElementsByTagName("tr");
                                    for (i = 0; i < tr.length; i++) {
                                        a = tr[i].getElementsByTagName("a")[0];
                                        txtValue = a.textContent || a.innerText;
                                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                            tr[i].style.display = "";
                                        } else {
                                            tr[i].style.display = "none";
                                        }
                                    }
                                }
                            </script>
                            <table id="example" class="table table-bordered table-hover" v-if="!cargando_radicaciones">
                                <thead>
                                <tr>
									<th>nombre solicitante</th>
									<th>fecha</th>
									<th>asunto</th>
									<th>detalle</th>
									<th>usuario</th>
									<th>editar</th>
                                </tr>
                                </thead>
                                <tbody id="myUL">
                                <tr v-for="tar in radicaciones">
                                    <td>{{ tar.nombre_solicitante }}</td>
                                    <td>{{ tar.fecha }}</td>
                                    <td>{{ tar.asunto }}</td>
                                    <td>{{ tar.texto_solicitud }}</td>
                                    <td>{{ tar.nombre }}</td>
									<td>
										<a v-bind:href="'<?php echo base_url()."index.php/radicaciones/ver_radi/";?>'+ tar.id">
											<button type="button" class="btn btn-info">Editar</button>
										</a>
									</td>                                </tr>
                                </tbody>
                            </table>
                            <div class="filter-container p-0 row">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>
</div>
</div>
<script>
	$(document).ready(function() {
		$('#example').DataTable();
	} );
</script>
<script type="text/javascript" src="<?php echo base_url() ?>js/appV.js"></script>
