<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>musicApp</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
      <style>
          body{
              background: url("https://blogdepelusita.files.wordpress.com/2012/04/2484855417_6f58539661_b.jpg") no-repeat;
              background-position: top;
              background-repeat: no-repeat;
              background-size: cover;
			  background-color: transparent;
              color: #ffffff;
              height: 100%;
              width: 100%;
          }
      </style>
  </head>
  <body>

      <div class="container">
       <div class="col-md-4 col-md-offset-4">
         <form class="form-signin" action="<?php echo site_url('login/auth');?>" method="post">
			   <h2 class="form-signin-heading">Ingresa los datos</h2>
			 <div class="mb-3">
			   <label for="username" class="sr-only">Username</label>
			   <input value="" autocomplete="off" type="email" name="email" class="form-control" placeholder="Email" required autofocus>
			 </div><br>
			 <div class="mb-3">
			 	<label for="password" class="sr-only">Password</label>
           		<input value="" autocomplete="off" type="password" name="password" class="form-control" placeholder="Password" required>
			 </div>
           <div class="checkbox">
             <label>
               <input type="checkbox" value="remember-me"> Recordar datos
             </label>
           </div>
           <button class="btn btn-lg btn-primary btn-block" type="submit">Ingresar</button>
         </form>
       </div>
       </div> <!-- /container -->
  </body>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script>
    <?php if($this->session->flashdata('msg')){ ?>
    Swal.fire({
        icon: 'error',
        title: 'Lo sentimos...',
        text: 'Dato errados! Intente de nuevo',
    })
    <?php } ?>
</script>

</html>
