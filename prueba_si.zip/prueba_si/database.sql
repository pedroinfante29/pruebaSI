CREATE DATABASE `db_prueba` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

-- db_prueba.pru_users definition

CREATE TABLE `pru_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tipo_usuario` int(11) NOT NULL,
  `intentos_login` int(11) NOT NULL,
  `date_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- db_prueba.pru_radicaciones definition

CREATE TABLE `pru_radicaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_solicitante` varchar(255) NOT NULL,
  `fecha` datetime NOT NULL,
  `asunto` varchar(255) NOT NULL,
  `texto_solicitud` text NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pru_radicaciones_FK` (`id_user`),
  CONSTRAINT `pru_radicaciones_FK` FOREIGN KEY (`id_user`) REFERENCES `pru_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4;