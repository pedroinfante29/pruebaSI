new Vue({
	el: '#controlador_radicaciones',
	data: {
		cargando_radicaciones: true,
		baseurl: 'index.php',
		radicacion_nueva: {
			nombre_solicitante: '',
			asunto: '',
			texto_solicitud: ''
		},
		radicacion_edit: {
			nombre_solicitante: '',
			asunto: '',
			texto_solicitud: '',
			id: ''
		},
		radicaciones: []
	},
	methods: {
		recuperarRadicaciones: function(){
			this.cargando_radicaciones = true;
			this.$http.get('http://localhost:8080/prueba_si/radicaciones/recuperar_radicaciones').then(function(respuesta){
				this.radicaciones = respuesta.body;
				this.cargando_radicaciones = false;
			}, function(){
				alert('No se han podido recuperar la lista de radicaciones.');
				this.cargando_radicaciones = false;
			});
		},
		crearRadicacion: function(){
			if(!this.validaNombre && !this.validarAsunto && !this.validarTexto){
				this.$http.post('http://localhost:8080/prueba_si/radicaciones/crear_radicacion', this.radicacion_nueva).then(function(){
					this.radicacion_nueva.nombre_solicitante = '';
					this.radicacion_nueva.asunto = '';
					this.radicacion_nueva.texto_solicitud = '';
					this.recuperarRadicaciones();
					location.replace('http://localhost:8080/prueba_si/page/');
				}, function(){
					alert('No se ha podido crear la radicacion.');
				});
			} else {
				Swal.fire({
					icon: 'error',
					title: 'Verifique',
					text: 'Los campos son obligatorios',
					// footer: '<a href>Why do I have this issue?</a>'
				})
			}
		},
		editarRadicacion: function(){
			this.$http.get('http://localhost:8080/prueba_si/radicaciones/editar_radi', this.radicacion_nueva).then(function(){
					this.radicacion_edit.nombre_solicitante = '';
					this.radicacion_edit.asunto = '';
					this.radicacion_edit.texto_solicitud = '';
					this.radicacion_edit.id = '';
					this.recuperarRadicaciones();
				}, function(){
					alert('No se ha podido crear la radicacion.');
				});

		}
	},
	computed:{
		validaNombre(){
			if(this.radicacion_nueva.nombre_solicitante){
				return false;
			} else{
				return true;
			}
		},
		validarAsunto(){
			if(this.radicacion_nueva.asunto){
				return false;
			} else{
				return true;
			}
		},
		validarTexto(){
			if(this.radicacion_nueva.texto_solicitud){
				return false;
			} else{
				return true;
			}
		}
	},
	created: function(){
		this.recuperarRadicaciones();
	}
});
